# My Work Planner

Jobs by category (drag to reorder), daily must-contact customer and connector with tap-to-call, calendar for time-bound jobs, contacts import, and backup/restore. Works offline on Android and Windows.

**Open / install:** https://biswajitmallicksp-commits.github.io/work-planner/

- **Android:** open the link in Chrome → ⋮ → Install app.
- **Windows:** open the link in Edge or Chrome → click the install icon in the address bar (or the "⬇ Install app" button in the app).

Each person's data stays on their own device. Use "Back up my data" in the Contacts tab to save a copy.
